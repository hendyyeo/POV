//
//  ViewController.swift
//  POV
//
//  Created by Hendy Rusnanto on 12/05/20.
//  Copyright © 2020 HR. All rights reserved.
//

import UIKit

class CameraView: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate {

    
    
    

    @IBOutlet weak var gridInUsed: UIImageView!                    // Camera Screen            (Style)
    @IBOutlet weak var ShowGridButton: UIButton!                   // Grid on/off button       (Style)
    @IBOutlet weak var cameraButton: UIButton!                     // Capture Button           (Style)
    @IBOutlet weak var upperView: UIView!                          // Upper View               (Style)
    @IBOutlet weak var bottomView: UIView!                         // Bottom View              (Style)
    @IBOutlet weak var gridPicker: UIPickerView!                   // Grid Picker Controller   (Style)
    
    
    
    var gridCondition: Int = 1                                                // Represent Grid On or Off
    var gridMode: Bool = false                                                // If Grid Condition on means edit the grid is true
    let gridType = [String](arrayLiteral: "The Phi Grid", "Fibonacci Spiral", "Rule of Third", "Golden Triangle", "Diagonal Rule")                                                                // Grids Style Data
    var GridCode = "Rule of Third"                                            // Tracking what grid is in use right now (String)
    var RoTColorCode = 0                                                      // Rule of Third Color numbers
    var GTColorCode = 0                                                       // Golden Triangle Color numbers
    var FSColorCode = 0                                                       // Fibonacci Spiral Color numbers
    var DRColorCode = 0                                                       // Diagonal Rule Color numbers
    var TPGColorCode = 0                                                      // The Phi Grid Color numbers
    var SwipeCode = 2                                                         // Tracking what grid is in use right now (Int)
    var rotationAngle: CGFloat!                                               // Value for rotating Picker View

    
    
    
    
    
    // View Style
    override func viewDidLoad() {
        super.viewDidLoad()
        ViewOpacity()
        InitialStyle()
    }
    
    
    
    
    
    // Tap Grid logo on the upper left to turn grid on / off    (Action)
    @IBAction func ShowGridButton(_ sender: Any) {
        ifGridButtonTapped()
    }
    
    
    
    
    // swipe Right to change next Grid Models   (Action)
    @IBAction func SwipeGridModeChange(_ sender: Any) {
        ifSwipedRight()
    }
    
    
    
    
    
    // swipe Left to change previous Grid Models   (Action)
    @IBAction func SwipeUndoGridModeChange(_ sender: Any) {
        ifSwipedLeft()
    }
    
    
    
    
    // Tap any screen to change grid color   (Action)
    @IBAction func GridColorButtonChange(_ sender: Any) {
        gridColorButtonTapped()
    }
}

